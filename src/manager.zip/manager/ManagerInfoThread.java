package manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import l1j.server.L1DatabaseFactory;
import l1j.server.server.GeneralThreadPool;
import l1j.server.server.utils.SQLUtil;
import l1j.server.server.utils.StringUtil;

public class ManagerInfoThread implements Runnable {
	public static Long AdenMake		= Long.valueOf(0L);
	public static Long AdenConsume	= Long.valueOf(0L);
	public static int AdenTax		= 0;
	public static float Bugdividend	= 0.0F;
	public static int AccountCount	= 0;
	public static int CharCount		= 0;
	public static int PvPCount		= 0;
	public static int PenaltyCount	= 0;
	public static int ClanMaker		= 0;
	public static int MaxUser		= 0;
	public static int count			= 0;
	public static NumberFormat nf	= NumberFormat.getInstance();
	private static ManagerInfoThread _instance;
	private final int _runTime;

	public static ManagerInfoThread getInstance() {
		if (_instance == null) {
			_instance = new ManagerInfoThread();
			_instance.ServerInfoLoad();
			Manager.getInstance().ServerInfoPrint(StringUtil.EmptyString + AdenMake, StringUtil.EmptyString + AdenConsume, StringUtil.EmptyString + AdenTax, StringUtil.EmptyString + nf.format(Bugdividend),
					StringUtil.EmptyString + AccountCount, StringUtil.EmptyString + CharCount, StringUtil.EmptyString + PvPCount, StringUtil.EmptyString + PenaltyCount, StringUtil.EmptyString + ClanMaker, StringUtil.EmptyString + MaxUser
					);
			_instance.start();
		}
		return _instance;
	}

	public ManagerInfoThread() {
		nf.setMaximumFractionDigits(1);
		nf.setMinimumFractionDigits(1);
		_runTime = 500;
	}

	public void start() {
		GeneralThreadPool.getInstance().scheduleAtFixedRate(_instance, 0L, _runTime);
	}

	@Override
	public void run() {
		try {
			if (++count >= 60) {
				count = 0;
				save();
			} else {
				Manager.getInstance().progressBarPrint(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void save() {
		ServerInfoMerge();
		Manager.getInstance().ServerInfoPrint(StringUtil.EmptyString + AdenMake, StringUtil.EmptyString + AdenConsume, StringUtil.EmptyString + AdenTax, StringUtil.EmptyString + nf.format(Bugdividend),
				StringUtil.EmptyString + AccountCount, StringUtil.EmptyString + CharCount, StringUtil.EmptyString + PvPCount, StringUtil.EmptyString + PenaltyCount, StringUtil.EmptyString + ClanMaker, StringUtil.EmptyString + MaxUser
				);
	}

	public static String getDate() {
		SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(StringUtil.DateFormatString, Locale.KOREA);
		return localSimpleDateFormat.format(Calendar.getInstance().getTime());
	}

	private static final String MERGE_QUERY = "INSERT INTO serverinfo "
			+ "(id, adenmake, adenconsume, adentax, bugdividend, accountcount, charcount, pvpcount, penaltycount, clanmaker, maxuser) "
			+ "VALUES "
			+ "(?,?,?,?,?,?,?,?,?,?,?) "
			+ "ON DUPLICATE KEY UPDATE "
			+ "adenmake=?, adenconsume=?, adentax=?, bugdividend=?, accountcount=?, charcount=?, pvpcount=?, penaltycount=?, clanmaker=?, maxuser=?";
	
	public synchronized void ServerInfoMerge() {
		Connection con			= null;
		PreparedStatement pstm	= null;
		ResultSet rs			= null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement(MERGE_QUERY);
			int i = 0;
			// INSERT
			pstm.setString(++i,	getDate());
			pstm.setLong(++i,	AdenMake.longValue());
			pstm.setLong(++i,	AdenConsume.longValue());
			pstm.setInt(++i,	AdenTax);
			pstm.setFloat(++i,	Bugdividend);
			pstm.setInt(++i,	AccountCount);
			pstm.setInt(++i,	CharCount);
			pstm.setInt(++i,	PvPCount);
			pstm.setInt(++i,	PenaltyCount);
			pstm.setInt(++i,	ClanMaker);
			pstm.setInt(++i,	MaxUser);
			
			// UPDATE
			pstm.setLong(++i,	AdenMake.longValue());
			pstm.setLong(++i,	AdenConsume.longValue());
			pstm.setInt(++i,	AdenTax);
			pstm.setFloat(++i,	Bugdividend);
			pstm.setInt(++i,	AccountCount);
			pstm.setInt(++i,	CharCount);
			pstm.setInt(++i,	PvPCount);
			pstm.setInt(++i,	PenaltyCount);
			pstm.setInt(++i,	ClanMaker);
			pstm.setInt(++i,	MaxUser);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			SQLUtil.close(rs, pstm, con);
		}
	}

	public void ServerInfoLoad() {
		Connection con			= null;
		PreparedStatement pstm	= null;
		ResultSet rs			= null;
		try {
			con		= L1DatabaseFactory.getInstance().getConnection();
			pstm	= con.prepareStatement("SELECT * FROM serverinfo WHERE id=?");
			pstm.setString(1, getDate());
			rs		= pstm.executeQuery();
			if(!rs.next())return;
			AdenMake		= Long.valueOf(rs.getLong("adenmake"));
			AdenConsume		= Long.valueOf(rs.getLong("adenconsume"));
			AdenTax			= rs.getInt("adentax");
			Bugdividend		= rs.getInt("bugdividend");
			AccountCount	= rs.getInt("accountcount");
			CharCount		= rs.getInt("charcount");
			PvPCount		= rs.getInt("pvpcount");
			PenaltyCount	= rs.getInt("penaltycount");
			ClanMaker		= rs.getInt("clanmaker");
			MaxUser			= rs.getInt("maxuser");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			SQLUtil.close(rs, pstm, con);
		}
	}
}
