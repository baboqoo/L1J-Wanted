package manager.composite;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import l1j.server.Config;
import l1j.server.L1DatabaseFactory;
import l1j.server.server.utils.SQLUtil;
//import manager.Manager;  // MANAGER DISABLED
import manager.SWTResourceManager;
import manager.dialog.LetterDialog;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class LetterComposite extends Composite {
	private Table table;
	@SuppressWarnings("unused")
	private LetterComposite lc;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public LetterComposite(final Composite parent, int style) {
		super(parent, style);
		lc = this;
		GridLayout gridLayout			= new GridLayout(1, false);
		gridLayout.horizontalSpacing	= 0;
		gridLayout.verticalSpacing		= 0;
		gridLayout.marginHeight			= 0;
		gridLayout.marginWidth			= 0;
		setLayout(gridLayout);
		
		Button btnNewButton = new Button(this, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				clear();
				load();
			}
		});
		GridData gd_btnNewButton	= new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton.heightHint	= 35;
		gd_btnNewButton.widthHint	= 150;
		btnNewButton.setLayoutData(gd_btnNewButton);
		btnNewButton.setText("Refresh");
		
		table = new Table(this, SWT.BORDER | SWT.FULL_SELECTION);
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				//
				try {
					TableItem item = table.getItem( table.getSelectionIndex() );
					if(item == null)
						return;

					Manager.getInstance();
					LetterDialog dialog = new LetterDialog(Manager.getShell(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
					dialog.open(item);
				} catch (Exception e2) { }
			}
		});
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		table.setHeaderVisible(true);
		table.setBackground(SWTResourceManager.getColor(51, 51, 51));
		table.setForeground(SWTResourceManager.getColor(255, 255, 255));
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(40);
		tblclmnNewColumn.setText("Number");
		
		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setWidth(80);
		tblclmnNewColumn_1.setText("Sent by");
		
		TableColumn tblclmnNewColumn_2 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_2.setWidth(150);
		tblclmnNewColumn_2.setText("Title");
		
		TableColumn tblclmnNewColumn_4 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_4.setWidth(80);
		tblclmnNewColumn_4.setText("Sent Date");

		//이부분 문제
		load();
	}
	
	public void delete(TableItem item) {
		String[] letter_data = (String[])item.getData();
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("DELETE FROM letter WHERE item_object_id = ?");
			pstm.setInt(1, Integer.parseInt(letter_data[0]));
			pstm.execute();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {		
			SQLUtil.close(rs, pstm, con);
		}
	}
	
	public void clear() {
		table.removeAll();
	}

	public void load() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String[] letter	= null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("SELECT * FROM letter WHERE receiver IN (SELECT char_name FROM characters WHERE AccessLevel=?) ORDER BY item_object_id DESC");
			pstm.setInt(1, Config.ALT.GMCODE);
			rs = pstm.executeQuery();
			while (rs.next()) {
				letter		= new String[6];
				letter[0]	= String.valueOf(rs.getInt("item_object_id"));
				letter[1]	= rs.getString("sender");
				letter[2]	= rs.getString("subject");
				letter[3]	= rs.getString("date");
				letter[4]	= rs.getString("content");
				letter[5]	= rs.getString("receiver");
				
				TableItem tableItem = new TableItem(table, SWT.NONE);
				tableItem.setData(letter);
				tableItem.setText(letter);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			SQLUtil.close(rs, pstm, con);
		}
	}
}

