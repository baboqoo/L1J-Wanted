package manager.dialog;

import l1j.server.Config;
import l1j.server.server.utils.StringUtil;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class ServerSettingDialog extends Dialog {
	protected Shell shell;
	protected Object result;
	public Text text_1;
	public Text text_2;
	public Text text_3;
	public ServerSettingDialog(Shell parent) {
		super(parent);
		setText("SWT Dialog");
	}
	
	public Object open() {
		Display display = getParent().getDisplay();
		createContents();
		shell.setBounds((display.getBounds().width/2)-(shell.getBounds().width/2), (display.getBounds().height/2)-(shell.getBounds().height/2), shell.getBounds().width, shell.getBounds().height);
		
		shell.open();
		shell.layout();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}
	
	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.CLOSE | SWT.TITLE | SWT.PRIMARY_MODAL);
		shell.setSize(228, 155);
		shell.setText("Server settings");
		
		Label expLabel = new Label(shell, SWT.NONE);
		expLabel.setBounds(10, 13, 47, 15);
		expLabel.setText("Exp:");
		text_1 = new Text(shell, SWT.BORDER);
		text_1.setBounds(63, 10, 110, 21);
		text_1.setText(Config.RATE.RATE_XP + StringUtil.EmptyString);
		Label rateLabel_1 = new Label(shell, SWT.NONE);
		rateLabel_1.setBounds(180, 13, 47, 15);
		rateLabel_1.setText("x");
		
		Label itemLabel = new Label(shell, SWT.NONE);
		itemLabel.setText("Items:");
		itemLabel.setBounds(10, 40, 47, 15);
		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(63, 37, 110, 21);
		text_2.setText(Config.RATE.RATE_DROP_ITEMS + StringUtil.EmptyString);
		Label rateLabel_2 = new Label(shell, SWT.NONE);
		rateLabel_2.setBounds(180, 40, 47, 15);
		rateLabel_2.setText("x");
		
		Label adenaLabel = new Label(shell, SWT.NONE);
		adenaLabel.setText("Adena:");
		adenaLabel.setBounds(10, 67, 47, 15);
		text_3 = new Text(shell, SWT.BORDER);
		text_3.setBounds(63, 64, 110, 21);
		text_3.setText(Config.RATE.RATE_DROP_ADENA + StringUtil.EmptyString);
		Label rateLabel_3 = new Label(shell, SWT.NONE);
		rateLabel_3.setBounds(180, 67, 47, 15);
		rateLabel_3.setText("x");
		
		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.setText("Change");
		btnNewButton.setBounds(63, 92, 110, 25);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				try{
					MessageBox dialog = new MessageBox(shell,SWT.OK|SWT.CANCEL|SWT.ICON_INFORMATION);
					dialog.setText("Warning!"); 
					dialog.setMessage("Are you sure you want to save it?"); 
					int flag = dialog.open();
					if (flag != SWT.OK) {// confirm
						return;
					}
					
					String exp_text		= text_1.getText();
					String item_text	= text_2.getText();
					String adena_text	= text_3.getText();
					
					if(StringUtil.isNullOrEmpty(exp_text)
						|| StringUtil.isNullOrEmpty(item_text)
						|| StringUtil.isNullOrEmpty(adena_text)){
						MessageBox dialog2 = new MessageBox(shell, SWT.CANCEL|SWT.ICON_INFORMATION);
						dialog2.setText("Warning!"); 
						dialog2.setMessage("The value is incorrect."); 
						dialog2.open();
						return;
					}
					
					double exp		= Double.parseDouble(exp_text);
					double item		= Double.parseDouble(item_text);
					double adena	= Double.parseDouble(adena_text);
					Config.RATE.RATE_XP = exp;
					Config.RATE.RATE_DROP_ITEMS = item;
					Config.RATE.RATE_DROP_ADENA = adena;
					
					MessageBox dialog2 = new MessageBox(shell, SWT.CANCEL|SWT.ICON_INFORMATION);
					dialog2.setText("Warning!");
					dialog2.setMessage("Changed correctly.");
					dialog2.open();
					
					shell.close();
				}catch(Exception e1){
					MessageBox dialog2 = new MessageBox(shell, SWT.CANCEL|SWT.ICON_INFORMATION);
					dialog2.setText("Warning!"); 
					dialog2.setMessage("The value is incorrect."); 
					dialog2.open();
				}
			}
		});
	}
	
}

